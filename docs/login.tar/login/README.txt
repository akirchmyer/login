Thanks for considering me for this position! I enjoyed working on this assignment and would love some feedback for my personal development.

I will be demoing my work at http://kirchmyer.net for the next week or so.

I hope you don't mind that I took the liberty to write some tests, it's sort of my specialty!

The most difficult part of this assignment was getting placeholders to work correctly in IE9. I opted to use the jquery-placeholder plugin as a polyfill.

Feel free to contact me with any questions at any of the following:
716-566-0987
akirchmyer@gmail.com
skype: akirchmyer

Regards,

Andrew Kirchmyer
