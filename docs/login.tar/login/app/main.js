define(['login'], function(LoginComponent) {
	var login = new LoginComponent();
	login.initialize();
});
